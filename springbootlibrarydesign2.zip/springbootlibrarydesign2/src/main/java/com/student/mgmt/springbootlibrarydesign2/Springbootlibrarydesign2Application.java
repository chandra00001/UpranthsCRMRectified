package com.student.mgmt.springbootlibrarydesign2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootlibrarydesign2Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbootlibrarydesign2Application.class, args);
	}

}
