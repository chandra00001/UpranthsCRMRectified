package com.student.mgmt.springbootlibrarydesign2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootlibrarydesign2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
